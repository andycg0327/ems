// Determine theme depending on device
var isAndroid = Framework7.prototype.device.android === true;
var isIos = Framework7.prototype.device.ios === true;
 
// Set Template7 global devices flags
Template7.global = {
    android: isAndroid,
    ios: isIos,
    token: '',
    sliderImages: ['01', '02', '03', '04', '05'],
    data: [],
    query_method: -1,
    query_column: 'FodderRatio',
    query_calendar: [],
    query_endDate: false,
    table_column: {
        OID: false,
        StartDate: true,
        PlantID: true,
        Type: true,
        AvgDays: true,
        AliveRatio: false,
        FodderWeight: false,
        FodderRatio: true,
        SellWeight: false,
        InitialAmount: false,
        FailureWeight: false,
        NonFailureWeight: false,
        EndDate: false
    },
    table_column_alias: {
        OID: "序號",
        StartDate: "開始日期",
        PlantID: "養雞場代號",
        Type: "雞種品名",
        AvgDays: "平均天數",
        AliveRatio: "育成率",
        FodderWeight: "飼料總公斤",
        FodderRatio: "飼料效率",
        SellWeight: "銷售總公斤",
        InitialAmount: "進貨隻數",
        FailureWeight: "下雞總公斤",
        NonFailureWeight: "不含下雞總重量",
        EndDate: "結算日期"
    },
    table_sort_column: 'OID',
    table_sort: 'ASC',
    chart_dot_x: "AvgDays",
    chart_dot_y: "FodderRatio"
};
Template7.registerHelper('compare', function(a, operator, b, options){
   if ((operator == "==" && a == b) || (operator == ">=" && a >= b) || (operator == "<=" && a <= b) || (operator == ">" && a > b) || (operator == "<" && a < b))
       return options.fn(this);
   else
       return options.inverse(this);
});
 
// Define Dom7
var $$ = Dom7;
 
// Change Through navbar layout to Fixed
if (isAndroid) {
    // Change class
    $$('.view.navbar-through').removeClass('navbar-through').addClass('navbar-fixed');
    // And move Navbar into Page
    $$('.view .navbar').prependTo('.view .page');
}

// Initialize app
var myApp = new Framework7({
    // init: false, //Disable App's automatic initialization
    material: isAndroid ? true : false,
    template7Pages: true,
    precompileTemplates: true,
    swipeBackPage: false,
    swipePanel: 'left',
    swipePanelActiveArea: 20,
 
    // Hide and show indicator during ajax requests
    onAjaxStart: function (xhr) {
        myApp.showIndicator();
    },
    onAjaxComplete: function (xhr) {
        myApp.hideIndicator();
    }
});

// If we need to use custom DOM library, let's save it to $$ variable:
var $$ = Dom7;

// Add view
var mainView = myApp.addView('.view-main', {
    // Because we want to use dynamic navbar, we need to enable it for this view:
    // dynamicNavbar: true
});

// Handle Cordova Device Ready Event
$$(document).on('deviceready', function() {
    console.log("Device is ready!");
});

myApp.onPageInit('index', function (page) {
    if (Framework7.prototype.device.android) {
        Dom7('head').append(
            '<link rel="stylesheet" href="lib/framework7/css/framework7.material.min.css">' +
            '<link rel="stylesheet" href="lib/framework7/css/framework7.material.colors.min.css">'
        );
    } else {
        Dom7('head').append(
            '<link rel="stylesheet" href="lib/framework7/css/framework7.ios.min.css">' +
            '<link rel="stylesheet" href="lib/framework7/css/framework7.ios.colors.min.css">'
        );
    }
    
    if(!Template7.global.fullData) {
        myApp.showIndicator();
        var url_param = location.search.substr(1).split('&');
        $.each(url_param, function(index, value) {
            var param = value.split('=');
            if(param[0] == "token")
                Template7.global.token = param[1];
        });
        $$.post('http://shhtest.shh.tw/plant_bim/ajaxIlan', {PlantOID: 2, token: Template7.global.token}, 
        function (data) {
            data = JSON.parse(data);
            Template7.global.Account = data.Account;
            Template7.global.User_level = data.User_level;
            Template7.global.fullData = data.Data;
            Template7.global.chart_dot_type = {};
            $.each(Template7.global.fullData, function(index, item) {
                item.StartDate = moment(item.StartDate);
                item.EndDate = moment(item.EndDate);
                if(!Template7.global.chart_dot_type[item.Type])
                    Template7.global.chart_dot_type[item.Type] = true;
            });
            myApp.hideIndicator();
    
            $("#menu_query").text(Template7.global.User_level !== 'Guest' ? '查詢與分析' : '查詢');
            mainView.router.load({
                url: 'main.html',
                pushstate: false
            });
        }, function () {
            myApp.hideIndicator();
            alert("Data download failed.");
        });
    }
}).trigger();

myApp.onPageAfterAnimation('main', function (page) {
    // $('.swiper-container').height();
    
    var mySwiper = myApp.swiper('.swiper-container', {
        pagination:'.swiper-pagination',
        autoHeight: true,
        autoplay: 3000,
        effect: 'fade',
        loop: true
    });
});

myApp.onPageInit('about', function (page) {

})
myApp.onPageInit('logout', function (page) {
     console.log("logout init");
     window.onerror = function myErrorHandler(errorMsg, url, lineNumber) {
    alert("Error occured: " + errorMsg);//or any message
    return false;
}
function logout(){
Android.logout();
}
$$('.confirm-ok_logout').on('click', function () {
   // alert(Android.logout());
    myApp.confirm('即將登出?', 'Custom Title', 
      function () {
        Android.logout();
      },
      function () {
        myApp.alert('You clicked Cancel button');
      }
    );
});
})