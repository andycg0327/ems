<?php
        //Enter your code here, enjoy!
function hex_dump($data, $newline="\n")
{
  static $from = '';
  static $to = '';

  static $width = 16; # number of bytes per line

  static $pad = '.'; # padding for non-visible characters

  if ($from==='')
  {
    for ($i=0; $i<=0xFF; $i++)
    {
      $from .= chr($i);
      $to .= ($i >= 0x20 && $i <= 0x7E) ? chr($i) : $pad;
    }
  }

  $hex = str_split(bin2hex($data), $width*2);
  $chars = str_split(strtr($data, $from, $to), $width);

  $offset = 0;
  foreach ($hex as $i => $line)
  {
    echo sprintf('%6X',$offset).' : '.implode(' ', str_split($line,2)) . ' [' . $chars[$i] . ']' . $newline;
    $offset += $width;
  }
}

function hex2raw( $str ){
  $chunks = str_split($str, 2);
  for( $i = 0; $i < sizeof($chunks); $i++ ) {
        $op .= chr( hexdec( $chunks[$i] ) );
    }
    return $op;
}

//128bit
//AES.Mode= CipherMode.CBC;
//           AES.Padding = PaddingMode.PKCS7;
//\\\==================================================
$pd="test1";
$pd_ =iconv('', 'UTF-16LE', $pd);
hex_dump($pd_);
echo "<br>";
//\\\==================================================
$key="test1";
//$key_ = mb_convert_encoding($key, 'UTF-16LE', "auto");
$key_ =iconv('', 'UTF-16LE', $key);
//$key__=utf8_encode($key);
//hex_dump($key_);
$key_= md5($key_,true);
hex_dump($key_);

echo "<br>";
//\\\==================================================

$iv="Niu2017";
//$iv_ = mb_convert_encoding($iv, 'UTF-8');
$iv_ =iconv('', 'UTF-16LE', $iv);

$iv_= md5($iv_,true);
hex_dump($iv_);
echo "<br>";
//\\\==================================================

//$iv_size = mcrypt_get_iv_size(MCRYPT_3DES, MCRYPT_MODE_CBC);
//echo "size=".$iv_size;

$ciphertext =openssl_encrypt ($pd_, 'aes-128-cbc', $key_, true, $iv_);
//$ciphertext = mcrypt_encrypt(MCRYPT_3DES, $key_,$pd_, MCRYPT_MODE_CBC, $iv_);
echo "<br>";

    # encode the resulting cipher text so it can be represented by a string
    $ciphertext_base64 = base64_encode($ciphertext);
    echo $ciphertext_base64;
    
//\\\==================================================

$_d_pd="Dyl7jTiYWxEekfIyFML4NQ==";    
$_d_pd_=base64_decode($_d_pd);
 
 
 $key="test2";
//$key_ = mb_convert_encoding($key, 'UTF-16LE', "auto");
$key_ =iconv('', 'UTF-16LE', $key);
//$key__=utf8_encode($key);
//hex_dump($key_);
$key_= md5($key_,true);
hex_dump($key_);
echo "<br>";
//\\\==================================================


$iv="Niu2017";
//$iv_ = mb_convert_encoding($iv, 'UTF-8');
$iv_ =iconv('', 'UTF-16LE', $iv);

$iv_= md5($iv_,true);
hex_dump($iv_);
echo "<br>";
//\\\==================================================



$ciphertext= openssl_decrypt($_d_pd_, 'AES-128-CBC', $key_, true, $iv_);

echo $ciphertext;
    
    
    